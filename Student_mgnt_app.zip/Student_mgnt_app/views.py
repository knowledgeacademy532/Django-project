from django.shortcuts import render,HttpResponse, HttpResponseRedirect
from .models import Student
from django.urls import reverse
from django.template import loader

# Create your views here.
def index(request):
    return render(request,'index.html')

def student_details(request):
    return render(request,'student_details.html')

def add_student(request):
    if request.method == 'POST':
        StudentName=request.POST['StudentName']
        Dob=request.POST[' Dob']
        City=request.POST['City']
        Qualification=request.POST['Qualification']
        Phone=int(request.POST['Phone'])
        Email=(request.POST['Email'])
        new_stud=Student(StudentName=StudentName,Dob=Dob,City=City,Qualification=Qualification,Phone= Phone,Email= Email)
        new_stud.save()
        return HttpResponseRedirect(reverse('student_details'))
   
def student_details(request):
   
    std=Student.objects.all()
    context={
        'std':std
    }
    print(context)
    return render(request,'student_details.html',context)

def edit_student(request,id):  
    studs= Student.objects.get(StudentId=id)  
    return render(request,'edit_student.html', {'studs':studs})  
       
def updates_student(request,id):  
    stud = Student.objects.get(StudentId=id)  
    stud.StudentName=request.POST['StudentName']
    stud.City=request.POST['City']
    stud.Qualification=request.POST['Qualification']
    stud.Phone=int(request.POST['Phone'])
    stud.Email=request.POST['Email']
    stud.save() 
    return HttpResponseRedirect(reverse('student_details'))  
   
def delete_student(request, id):
    member = Student.objects.get(StudentId=id)
    member.delete()
    return HttpResponseRedirect(reverse('student_details'))