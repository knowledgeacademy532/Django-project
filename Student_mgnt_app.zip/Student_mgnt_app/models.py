from django.db import models


class Student(models.Model):
    StudentId=models.AutoField(primary_key=True)
    StudentName=models.CharField(max_length=100,null=False)
    Dob=models.DateField()
    City=models.CharField(max_length=100,null=False)
    Qualification=models.CharField(max_length=100,null=False)
    Email=models.CharField(max_length=100,null=False)
    Phone=models.IntegerField(default=0)

